<?php

return [
    'db' => [
        'host'    => 'localhost',
        'dbname'  => 'books',
        'charset' => 'utf8',
        'user'    => 'librero',
        'password' => '1234'
    ]
];
/*Esn este archivo se crea un array donde se alamacena la informacion de acceso al a base de datos*/