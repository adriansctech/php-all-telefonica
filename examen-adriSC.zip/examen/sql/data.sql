INSERT INTO `pisos`
(`direccion`,`precio`,`descripcion`)
VALUES
("Entenza 23", 1255, "Cuarto piso muy soleado"),
("Juan23 12", 3099, "Sin ascensor"),
("San Nicolas 34", 999, "Gastos de la comunidad incluidos"),
("Santa Rosa 45", 300, "Atico"),
("San Lorenzo 49", 400, "Sin ascensor"),
("San Eloy 11", 500, "Pertenece a inmobiliaria"),
("Pintor Cabrera", 325 ,"Bonitas vistas"),
("Cid 5", 425, "Escaleras de caracol"),
("Entenza 28", 500, "Cuatro habitaciones"),
("Alfafara 7", 599, "Estudio"),
("Plaza mayor 87", 325, "Con balcón"),
("Cami 22",725, "Muy grande");