<?php 

return [
	'db' => [
		'host' => 'localhost',
		'dbname' => 'pisos',
		'charset' => 'utf8',
		'user' => 'librero',/*Aqui intorducir nombre de usuario con pocos privilegios*/
		'password' => '1234'/*Introducir password del usuario de mysql anterior*/
	]
];

?>