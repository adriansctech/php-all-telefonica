<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Prueba formulario</title>
</head>
<body>
	Bienvenido <?= $_SESSION['username']; ?>
	<a href="logout.php">Cerrar sesión</a>
</body>
</html>